import 'app_localizations.dart';

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get language => 'عربي';

  @override
  String get addPhoneNullFieldError => 'يجب ملء جميع الحقول لبدء التتبع.';

  @override
  String get addPhoneLimitError => 'انتهى حقك في الاستخدام.';

  @override
  String get tryFree => 'قم بتجربته مجانا';

  @override
  String get freeTrialTitle => 'جرب 8 ساعات قسط مجانًا 😍';

  @override
  String get freeTrialLabel1 => 'إشعارات النشاط الفوري';

  @override
  String get freeTrialLabel2 => 'تقارير مفصلة عن النشاط';

  @override
  String get freeTrialLabel3 => 'وصول غير محدود إلى جميع الميزات';

  @override
  String get freeTrialTryButton => 'ابدأ الإصدار التجريبي المجاني';

  @override
  String get freeTrialCaption => 'تنتهي الفترة التجريبية المجانية بعد 8 ساعات من تاريخ بدئها. خلال هذه الفترة ، سيكون لديك الميزات المميزة المذكورة أعلاه. إذا لم يتم تجديد الحزمة في نهاية الفترة ، يتم تعطيل الميزات المميزة. أنت بحاجة لشراء الحزمة.';

  @override
  String get close => 'قريب';

  @override
  String get pricesOptionsTitle => 'لا تضغط على الحدود! 😊';

  @override
  String get contin => 'يكمل';

  @override
  String get pricesOptionsCaption => 'يمكنك إلغاء الفاتورة المجددة في أي وقت. سيتم الدفع من خلال حساب Google Pay الخاص بك عندما تقرر شراء الاشتراك. سيتم تجديد اشتراكك قبل 24 ساعة من انتهاء صلاحية اشتراكك.';

  @override
  String get activities => 'أنشطة';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen الدعم';

  @override
  String get emailSupportBody => 'أهلاً بك! يمكنك كتابة رسالتك هنا';

  @override
  String get support => 'الدعم';

  @override
  String get termsofuse => 'تعليمات الاستخدام';

  @override
  String get privacypolicy => 'سياسة الخصوصية';

  @override
  String get rateus => 'قيمنا';

  @override
  String get premiumBenefits => 'مزايا العضو المميز';

  @override
  String get generalSettings => 'الاعدادات العامة';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get premium => 'طليعة';

  @override
  String get addNumber => 'أضف رقم';

  @override
  String get switchPro => 'قم بالتبديل إلى الإصدار المميز';

  @override
  String get procesing => 'يعالج';

  @override
  String get onHold => 'في الانتظار';

  @override
  String get nullActivityText => 'لم يتم العثور على نشاط مسجل';

  @override
  String get nullActivityCaption => 'الرقم المعروض ليس له نشاط مسجل حتى الآن. عند العثور على النشاط ، سيبدأ إدراج السجلات.';

  @override
  String get activeTime => 'وقت نشط';

  @override
  String get second => 'ثانيا';

  @override
  String get onlineTime => 'وقت النشاط';

  @override
  String get activeNumber => 'رقم نشط';

  @override
  String get daily => 'جونلوك';

  @override
  String get weekly => 'هافتاليك';

  @override
  String get successful => 'عملية ناجحة';

  @override
  String get successfulAddNumberCaption => 'تم إضافة رقمك بنجاح. ستتلقى إخطارًا عند بدء التتبع. قد تستغرق هذه العملية وقتًا اعتمادًا على كثافة النظام.';

  @override
  String get okay => 'تمام';

  @override
  String get unsuccessful => 'فشلت العملية';

  @override
  String get unsuccessfulCaption => 'واجهتنا مشكلة. الرجاء معاودة المحاولة في وقت لاحق.';

  @override
  String get numberSettings => 'إعدادات الرقم';

  @override
  String get namedNumber => 'اسم الرقم';

  @override
  String get onlineNotification => 'إعلام عبر الإنترنت';

  @override
  String get removeNumber => 'إزالة الرقم';

  @override
  String get removeNumberCaption => 'انتباه! عند حذف الرقم ، يتم حذف الأنشطة السابقة.';

  @override
  String get newPhoneCaption => 'من أجل استخدام التطبيق ، تحتاج إلى إضافة رقم هاتف Whatsapp.';

  @override
  String get startTracking => 'بدء تتبع';

  @override
  String get trackingPolicy => 'من خلال الاستمرار ، فإنك توافق على سياسة الخصوصية واتفاقية ترخيص المستخدم النهائي';

  @override
  String get filter => 'منقي';

  @override
  String get changeLang => 'تغيير اللغة';
}
