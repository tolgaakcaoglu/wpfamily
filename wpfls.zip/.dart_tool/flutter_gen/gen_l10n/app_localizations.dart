import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_bn.dart';
import 'app_localizations_en.dart';
import 'app_localizations_es.dart';
import 'app_localizations_fr.dart';
import 'app_localizations_hi.dart';
import 'app_localizations_id.dart';
import 'app_localizations_pt.dart';
import 'app_localizations_ru.dart';
import 'app_localizations_zh.dart';

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'gen_l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale) : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates = <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('bn'),
    Locale('en'),
    Locale('es'),
    Locale('fr'),
    Locale('hi'),
    Locale('id'),
    Locale('pt'),
    Locale('ru'),
    Locale('zh')
  ];

  /// Current languages
  ///
  /// In en, this message translates to:
  /// **'English'**
  String get language;

  /// No description provided for @addPhoneNullFieldError.
  ///
  /// In en, this message translates to:
  /// **'You must fill in all fields to start tracking.'**
  String get addPhoneNullFieldError;

  /// No description provided for @addPhoneLimitError.
  ///
  /// In en, this message translates to:
  /// **'Your right of use has expired.'**
  String get addPhoneLimitError;

  /// No description provided for @tryFree.
  ///
  /// In en, this message translates to:
  /// **'Try it for free'**
  String get tryFree;

  /// No description provided for @freeTrialTitle.
  ///
  /// In en, this message translates to:
  /// **'Try 8 hours premium for free 😍'**
  String get freeTrialTitle;

  /// No description provided for @freeTrialLabel1.
  ///
  /// In en, this message translates to:
  /// **'Instant activity notifications'**
  String get freeTrialLabel1;

  /// No description provided for @freeTrialLabel2.
  ///
  /// In en, this message translates to:
  /// **'Detailed activity reports'**
  String get freeTrialLabel2;

  /// No description provided for @freeTrialLabel3.
  ///
  /// In en, this message translates to:
  /// **'Unlimited access to all features'**
  String get freeTrialLabel3;

  /// No description provided for @freeTrialTryButton.
  ///
  /// In en, this message translates to:
  /// **'Start Free Trial'**
  String get freeTrialTryButton;

  /// No description provided for @freeTrialCaption.
  ///
  /// In en, this message translates to:
  /// **'Your free trial expires 8 hours from the date you started it. During this period, you will have the premium features mentioned above. If the package is not renewed at the end of the period, the premium features are disabled. You need to buy the package.'**
  String get freeTrialCaption;

  /// No description provided for @close.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get close;

  /// No description provided for @pricesOptionsTitle.
  ///
  /// In en, this message translates to:
  /// **'Don\'t hit the limits! 😊'**
  String get pricesOptionsTitle;

  /// No description provided for @contin.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get contin;

  /// No description provided for @pricesOptionsCaption.
  ///
  /// In en, this message translates to:
  /// **'You can cancel the renewed invoice at any time. Payment will be made through your Google Pay account when you decide to purchase the subscription. Your subscription will be renewed 24 hours before your subscription expires.'**
  String get pricesOptionsCaption;

  /// No description provided for @activities.
  ///
  /// In en, this message translates to:
  /// **'Activities'**
  String get activities;

  /// No description provided for @emailSupportSubject.
  ///
  /// In en, this message translates to:
  /// **'Wp Family Last Seen Support'**
  String get emailSupportSubject;

  /// No description provided for @emailSupportBody.
  ///
  /// In en, this message translates to:
  /// **'Hello there! You can write your message here'**
  String get emailSupportBody;

  /// No description provided for @support.
  ///
  /// In en, this message translates to:
  /// **'Support'**
  String get support;

  /// No description provided for @termsofuse.
  ///
  /// In en, this message translates to:
  /// **'Terms of use'**
  String get termsofuse;

  /// No description provided for @privacypolicy.
  ///
  /// In en, this message translates to:
  /// **'Privacy Policy'**
  String get privacypolicy;

  /// No description provided for @rateus.
  ///
  /// In en, this message translates to:
  /// **'Rate Us'**
  String get rateus;

  /// No description provided for @premiumBenefits.
  ///
  /// In en, this message translates to:
  /// **'Premium Member Benefits'**
  String get premiumBenefits;

  /// No description provided for @generalSettings.
  ///
  /// In en, this message translates to:
  /// **'General Settings'**
  String get generalSettings;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'E-mail'**
  String get email;

  /// No description provided for @premium.
  ///
  /// In en, this message translates to:
  /// **'Premium'**
  String get premium;

  /// No description provided for @addNumber.
  ///
  /// In en, this message translates to:
  /// **'Add Number'**
  String get addNumber;

  /// No description provided for @switchPro.
  ///
  /// In en, this message translates to:
  /// **'Switch to premium'**
  String get switchPro;

  /// No description provided for @procesing.
  ///
  /// In en, this message translates to:
  /// **'Processing'**
  String get procesing;

  /// No description provided for @onHold.
  ///
  /// In en, this message translates to:
  /// **'On hold'**
  String get onHold;

  /// No description provided for @nullActivityText.
  ///
  /// In en, this message translates to:
  /// **'No recorded activity found'**
  String get nullActivityText;

  /// No description provided for @nullActivityCaption.
  ///
  /// In en, this message translates to:
  /// **'The number shown has no registered activity yet. When the activity is found, the records will start to be listed.'**
  String get nullActivityCaption;

  /// No description provided for @activeTime.
  ///
  /// In en, this message translates to:
  /// **'Active time'**
  String get activeTime;

  /// No description provided for @second.
  ///
  /// In en, this message translates to:
  /// **'sec'**
  String get second;

  /// No description provided for @onlineTime.
  ///
  /// In en, this message translates to:
  /// **'Activite Time'**
  String get onlineTime;

  /// No description provided for @activeNumber.
  ///
  /// In en, this message translates to:
  /// **'Active Number'**
  String get activeNumber;

  /// No description provided for @daily.
  ///
  /// In en, this message translates to:
  /// **'Daily'**
  String get daily;

  /// No description provided for @weekly.
  ///
  /// In en, this message translates to:
  /// **'Weekly'**
  String get weekly;

  /// No description provided for @successful.
  ///
  /// In en, this message translates to:
  /// **'Transaction Successful'**
  String get successful;

  /// No description provided for @successfulAddNumberCaption.
  ///
  /// In en, this message translates to:
  /// **'Your number has been successfully added. You will receive notification when tracking starts. This process may take time depending on the system density.'**
  String get successfulAddNumberCaption;

  /// No description provided for @okay.
  ///
  /// In en, this message translates to:
  /// **'Ok'**
  String get okay;

  /// No description provided for @unsuccessful.
  ///
  /// In en, this message translates to:
  /// **'Operation Failed'**
  String get unsuccessful;

  /// No description provided for @unsuccessfulCaption.
  ///
  /// In en, this message translates to:
  /// **'We ran into a problem. please try again later.'**
  String get unsuccessfulCaption;

  /// No description provided for @numberSettings.
  ///
  /// In en, this message translates to:
  /// **'Number Settings'**
  String get numberSettings;

  /// No description provided for @namedNumber.
  ///
  /// In en, this message translates to:
  /// **'Name the Number'**
  String get namedNumber;

  /// No description provided for @onlineNotification.
  ///
  /// In en, this message translates to:
  /// **'Online Notification'**
  String get onlineNotification;

  /// No description provided for @removeNumber.
  ///
  /// In en, this message translates to:
  /// **'Remove Number'**
  String get removeNumber;

  /// No description provided for @removeNumberCaption.
  ///
  /// In en, this message translates to:
  /// **'Attention! When you delete the number, past activities are deleted.'**
  String get removeNumberCaption;

  /// No description provided for @newPhoneCaption.
  ///
  /// In en, this message translates to:
  /// **'In order to use the application, you need to add a Whatsapp phone number.'**
  String get newPhoneCaption;

  /// No description provided for @startTracking.
  ///
  /// In en, this message translates to:
  /// **'Start Tracking'**
  String get startTracking;

  /// No description provided for @trackingPolicy.
  ///
  /// In en, this message translates to:
  /// **'By continuing you agree to our Privacy Policy and EULA'**
  String get trackingPolicy;

  /// No description provided for @filter.
  ///
  /// In en, this message translates to:
  /// **'Filter'**
  String get filter;

  /// No description provided for @changeLang.
  ///
  /// In en, this message translates to:
  /// **'Change language'**
  String get changeLang;
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) => <String>['ar', 'bn', 'en', 'es', 'fr', 'hi', 'id', 'pt', 'ru', 'zh'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {


  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar': return AppLocalizationsAr();
    case 'bn': return AppLocalizationsBn();
    case 'en': return AppLocalizationsEn();
    case 'es': return AppLocalizationsEs();
    case 'fr': return AppLocalizationsFr();
    case 'hi': return AppLocalizationsHi();
    case 'id': return AppLocalizationsId();
    case 'pt': return AppLocalizationsPt();
    case 'ru': return AppLocalizationsRu();
    case 'zh': return AppLocalizationsZh();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.'
  );
}
