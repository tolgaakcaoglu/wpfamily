import 'app_localizations.dart';

/// The translations for Spanish Castilian (`es`).
class AppLocalizationsEs extends AppLocalizations {
  AppLocalizationsEs([String locale = 'es']) : super(locale);

  @override
  String get language => 'Español';

  @override
  String get addPhoneNullFieldError => 'Debes completar todos los campos para comenzar a rastrear.';

  @override
  String get addPhoneLimitError => 'Su derecho de uso ha caducado.';

  @override
  String get tryFree => 'Pruébalo gratis';

  @override
  String get freeTrialTitle => 'Prueba 8 horas premium gratis 😍';

  @override
  String get freeTrialLabel1 => 'Notificaciones de actividad instantáneas';

  @override
  String get freeTrialLabel2 => 'Informes detallados de actividad';

  @override
  String get freeTrialLabel3 => 'Acceso ilimitado a todas las funciones';

  @override
  String get freeTrialTryButton => 'Empiza la prueba gratuita';

  @override
  String get freeTrialCaption => 'Su prueba gratuita vence 8 horas después de la fecha en que la inició. Durante este período, tendrá las características premium mencionadas anteriormente. Si el paquete no se renueva al final del período, las funciones premium se desactivan. Necesitas comprar el paquete.';

  @override
  String get close => 'Cerca';

  @override
  String get pricesOptionsTitle => '¡No alcances los límites! 😊';

  @override
  String get contin => 'Continuar';

  @override
  String get pricesOptionsCaption => 'Puede cancelar la factura renovada en cualquier momento. El pago se realizará a través de su cuenta de Google Pay cuando decida comprar la suscripción. Su suscripción se renovará 24 horas antes de que caduque su suscripción.';

  @override
  String get activities => 'Activities';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen Apoyo';

  @override
  String get emailSupportBody => '¡Hola! Puedes escribir tu mensaje aquí';

  @override
  String get support => 'Apoyo';

  @override
  String get termsofuse => 'Términos de Uso';

  @override
  String get privacypolicy => 'Privacy Policy';

  @override
  String get rateus => 'Nos califica';

  @override
  String get premiumBenefits => 'Beneficios para miembros premium';

  @override
  String get generalSettings => 'Configuración general';

  @override
  String get email => 'Correo electrónico';

  @override
  String get premium => 'Pro';

  @override
  String get addNumber => 'Añade un número';

  @override
  String get switchPro => 'Cambiar a premium';

  @override
  String get procesing => 'Procesando';

  @override
  String get onHold => 'En espera';

  @override
  String get nullActivityText => 'No se encontró actividad registrada';

  @override
  String get nullActivityCaption => 'El número mostrado aún no tiene actividad registrada. Cuando se encuentre la actividad, los registros comenzarán a aparecer en la lista.';

  @override
  String get activeTime => 'Tiempo activo';

  @override
  String get second => 'seg';

  @override
  String get onlineTime => 'Tiempo de actividad';

  @override
  String get activeNumber => 'Número activo';

  @override
  String get daily => 'Diariamente';

  @override
  String get weekly => 'Semanalmente';

  @override
  String get successful => 'Transacción exitosa';

  @override
  String get successfulAddNumberCaption => 'Su número ha sido agregado con éxito. Recibirá una notificación cuando comience el seguimiento. Este proceso puede llevar tiempo dependiendo de la densidad del sistema.';

  @override
  String get okay => 'De acuerdo';

  @override
  String get unsuccessful => 'Operación fallida';

  @override
  String get unsuccessfulCaption => 'Nos encontramos con un problema. Por favor, inténtelo de nuevo más tarde.';

  @override
  String get numberSettings => 'Configuración de números';

  @override
  String get namedNumber => 'Nombra el número';

  @override
  String get onlineNotification => 'Notificación en línea';

  @override
  String get removeNumber => 'Eliminar número';

  @override
  String get removeNumberCaption => '¡Atención! Cuando elimina el número, se eliminan las actividades pasadas.';

  @override
  String get newPhoneCaption => 'Para usar la aplicación, debe agregar un número de teléfono de Whatsapp.';

  @override
  String get startTracking => 'Iniciar seguimiento';

  @override
  String get trackingPolicy => 'Al continuar, acepta nuestra Política de privacidad y EULA';

  @override
  String get filter => 'Filtrar';

  @override
  String get changeLang => 'Cambiar idioma';
}
