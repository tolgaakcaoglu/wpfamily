import 'app_localizations.dart';

/// The translations for Portuguese (`pt`).
class AppLocalizationsPt extends AppLocalizations {
  AppLocalizationsPt([String locale = 'pt']) : super(locale);

  @override
  String get language => 'Português';

  @override
  String get addPhoneNullFieldError => 'Você deve preencher todos os campos para iniciar o rastreamento.';

  @override
  String get addPhoneLimitError => 'Seu direito de uso expirou.';

  @override
  String get tryFree => 'Experimente Grátis';

  @override
  String get freeTrialTitle => 'Experimente 8 horas premium de graça 😍';

  @override
  String get freeTrialLabel1 => 'Notificações instantâneas de atividade';

  @override
  String get freeTrialLabel2 => 'Relatórios detalhados de atividades';

  @override
  String get freeTrialLabel3 => 'Acesso ilimitado a todos os recursos';

  @override
  String get freeTrialTryButton => 'Iniciar avaliação gratuita';

  @override
  String get freeTrialCaption => 'Sua avaliação gratuita expira 8 horas a partir da data em que você a iniciou. Durante este período, você terá os recursos premium mencionados acima. Se o pacote não for renovado ao final do período, os recursos premium serão desativados. Você precisa comprar o pacote.';

  @override
  String get close => 'Perto';

  @override
  String get pricesOptionsTitle => 'Não ultrapasse os limites! 😊';

  @override
  String get contin => 'Continuar';

  @override
  String get pricesOptionsCaption => 'Você pode cancelar a fatura renovada a qualquer momento. O pagamento será feito por meio de sua conta do Google Pay quando você decidir comprar a assinatura. Sua assinatura será renovada 24 horas antes de sua assinatura expirar.';

  @override
  String get activities => 'Atividades';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen Apoiar';

  @override
  String get emailSupportBody => 'Olá! Você pode escrever sua mensagem aqui';

  @override
  String get support => 'Apoiar';

  @override
  String get termsofuse => 'Termos de uso';

  @override
  String get privacypolicy => 'Política de Privacidade';

  @override
  String get rateus => 'Nos avalie';

  @override
  String get premiumBenefits => 'Benefícios de Membro Premium';

  @override
  String get generalSettings => 'Configurações Gerais';

  @override
  String get email => 'E-mail';

  @override
  String get premium => 'Pró';

  @override
  String get addNumber => 'Adicionar número';

  @override
  String get switchPro => 'Mudar para premium';

  @override
  String get procesing => 'Em processamento';

  @override
  String get onHold => 'Em espera';

  @override
  String get nullActivityText => 'Nenhuma atividade registrada encontrada';

  @override
  String get nullActivityCaption => 'O número mostrado ainda não possui atividade registrada. Quando a atividade for encontrada, os registros começarão a ser listados.';

  @override
  String get activeTime => 'Tempo ativo';

  @override
  String get second => 'seg';

  @override
  String get onlineTime => 'Tempo de atividade';

  @override
  String get activeNumber => 'Número ativo';

  @override
  String get daily => 'Diário';

  @override
  String get weekly => 'Semanalmente';

  @override
  String get successful => 'Transação bem-sucedida';

  @override
  String get successfulAddNumberCaption => 'Seu número foi adicionado com sucesso. Você receberá uma notificação quando o rastreamento começar. Este processo pode demorar dependendo da densidade do sistema.';

  @override
  String get okay => 'Ok';

  @override
  String get unsuccessful => 'Operação falhou';

  @override
  String get unsuccessfulCaption => 'Encontramos um problema. por favor, tente novamente mais tarde.';

  @override
  String get numberSettings => 'Configurações de número';

  @override
  String get namedNumber => 'Nomeie o número';

  @override
  String get onlineNotification => 'Notificação on-line';

  @override
  String get removeNumber => 'Remover número';

  @override
  String get removeNumberCaption => 'Atenção! Quando você exclui o número, as atividades anteriores são excluídas.';

  @override
  String get newPhoneCaption => 'Para usar o aplicativo, você precisa adicionar um número de telefone Whatsapp.';

  @override
  String get startTracking => 'Iniciar rastreamento';

  @override
  String get trackingPolicy => 'Ao continuar, você concorda com nossa Política de Privacidade e EULA';

  @override
  String get filter => 'Filtro';

  @override
  String get changeLang => 'Mudar idioma';
}
