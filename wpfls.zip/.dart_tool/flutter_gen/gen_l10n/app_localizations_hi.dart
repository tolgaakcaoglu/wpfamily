import 'app_localizations.dart';

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get language => 'हिन्दी';

  @override
  String get addPhoneNullFieldError => 'ट्रैकिंग शुरू करने के लिए आपको सभी फ़ील्ड भरने होंगे।';

  @override
  String get addPhoneLimitError => 'आपके उपयोग का अधिकार समाप्त हो गया है।';

  @override
  String get tryFree => 'इसका उपयोग मुफ्त में करें';

  @override
  String get freeTrialTitle => '8 घंटे का प्रीमियम मुफ़्त में आज़माएं 😍';

  @override
  String get freeTrialLabel1 => 'त्वरित गतिविधि सूचनाएं';

  @override
  String get freeTrialLabel2 => 'विस्तृत गतिविधि रिपोर्ट';

  @override
  String get freeTrialLabel3 => 'सभी सुविधाओं तक असीमित पहुंच';

  @override
  String get freeTrialTryButton => 'निशुल्क आजमाइश शुरु करें';

  @override
  String get freeTrialCaption => 'आपके नि:शुल्क परीक्षण की समय-सीमा आपके द्वारा शुरू किए जाने की तारीख से 8 घंटे के भीतर समाप्त हो जाती है। इस अवधि के दौरान, आपके पास ऊपर वर्णित प्रीमियम सुविधाएं होंगी। यदि अवधि के अंत में पैकेज का नवीनीकरण नहीं किया जाता है, तो प्रीमियम सुविधाएँ अक्षम हो जाती हैं। आपको पैकेज खरीदना होगा।';

  @override
  String get close => 'बंद करना';

  @override
  String get pricesOptionsTitle => 'सीमा मत मारो! 😊';

  @override
  String get contin => 'जारी रखना';

  @override
  String get pricesOptionsCaption => 'आप किसी भी समय नवीनीकृत चालान रद्द कर सकते हैं। जब आप सदस्यता खरीदने का निर्णय लेंगे तो भुगतान आपके Google पे खाते के माध्यम से किया जाएगा। आपकी सदस्यता समाप्त होने से 24 घंटे पहले आपकी सदस्यता नवीनीकृत हो जाएगी।';

  @override
  String get activities => 'गतिविधियां';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen सहायता';

  @override
  String get emailSupportBody => 'नमस्ते! आप अपना संदेश यहां लिख सकते हैं';

  @override
  String get support => 'सहायता';

  @override
  String get termsofuse => 'उपयोग की शर्तें';

  @override
  String get privacypolicy => 'गोपनीयता नीति';

  @override
  String get rateus => 'हमें रेटिंग दें';

  @override
  String get premiumBenefits => 'प्रीमियम सदस्य लाभ';

  @override
  String get generalSettings => 'सामान्य सेटिंग्स';

  @override
  String get email => 'ईमेल';

  @override
  String get premium => 'समर्थक';

  @override
  String get addNumber => 'अंक जोड़ो';

  @override
  String get switchPro => 'प्रीमियम पर स्विच करें';

  @override
  String get procesing => 'प्रसंस्करण';

  @override
  String get onHold => 'होल्ड पर';

  @override
  String get nullActivityText => 'कोई रिकॉर्ड की गई गतिविधि नहीं मिली';

  @override
  String get nullActivityCaption => 'दिखाए गए नंबर में अभी तक कोई पंजीकृत गतिविधि नहीं है। जब गतिविधि पाई जाती है, तो रिकॉर्ड सूचीबद्ध होना शुरू हो जाएंगे।';

  @override
  String get activeTime => 'सक्रिय समय';

  @override
  String get second => 'दूसरा';

  @override
  String get onlineTime => 'सक्रिय समय';

  @override
  String get activeNumber => 'सक्रिय संख्या';

  @override
  String get daily => 'रोज';

  @override
  String get weekly => 'साप्ताहिक';

  @override
  String get successful => 'लेन-देन सफल';

  @override
  String get successfulAddNumberCaption => 'आपका नंबर सफलतापूर्वक जोड़ दिया गया है। ट्रैकिंग शुरू होने पर आपको सूचना प्राप्त होगी। सिस्टम घनत्व के आधार पर इस प्रक्रिया में समय लग सकता है।';

  @override
  String get okay => 'ठीक';

  @override
  String get unsuccessful => 'प्रचालन विफल रहा';

  @override
  String get unsuccessfulCaption => 'हम एक समस्या में पड़ गए। कृपया बाद में पुन: प्रयास करें।';

  @override
  String get numberSettings => 'नंबर सेटिंग्स';

  @override
  String get namedNumber => 'नंबर का नाम दें';

  @override
  String get onlineNotification => 'ऑनलाइन अधिसूचना';

  @override
  String get removeNumber => 'नंबर हटाएं';

  @override
  String get removeNumberCaption => 'ध्यान! जब आप नंबर हटाते हैं, तो पिछली गतिविधियां हटा दी जाती हैं।';

  @override
  String get newPhoneCaption => 'एप्लिकेशन का उपयोग करने के लिए, आपको एक व्हाट्सएप फोन नंबर जोड़ना होगा।';

  @override
  String get startTracking => 'ट्रैकिंग शुरू करें';

  @override
  String get trackingPolicy => 'जारी रखकर आप हमारी गोपनीयता नीति और EULA . से सहमत होते हैं';

  @override
  String get filter => 'फ़िल्टर';

  @override
  String get changeLang => 'भाषा बदलो';
}
