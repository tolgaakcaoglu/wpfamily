import 'app_localizations.dart';

/// The translations for French (`fr`).
class AppLocalizationsFr extends AppLocalizations {
  AppLocalizationsFr([String locale = 'fr']) : super(locale);

  @override
  String get language => 'Français';

  @override
  String get addPhoneNullFieldError => 'Vous devez remplir tous les champs pour commencer le suivi.';

  @override
  String get addPhoneLimitError => 'Votre droit d\'utilisation a expiré.';

  @override
  String get tryFree => 'Essayez-le gratuitement';

  @override
  String get freeTrialTitle => 'Essayez 8 heures premium gratuitement 😍';

  @override
  String get freeTrialLabel1 => 'Notifications d\'activité instantanées';

  @override
  String get freeTrialLabel2 => 'Rapports d\'activité détaillés';

  @override
  String get freeTrialLabel3 => 'Accès illimité à toutes les fonctionnalités';

  @override
  String get freeTrialTryButton => 'Commencer l\'essai gratuit';

  @override
  String get freeTrialCaption => 'Votre essai gratuit expire 8 heures après la date à laquelle vous l\'avez commencé. Pendant cette période, vous disposerez des fonctionnalités premium mentionnées ci-dessus. Si le forfait n\'est pas renouvelé à la fin de la période, les fonctionnalités premium sont désactivées. Vous devez acheter le forfait.';

  @override
  String get close => 'proche';

  @override
  String get pricesOptionsTitle => 'Ne dépassez pas les limites ! 😊';

  @override
  String get contin => 'Continuer';

  @override
  String get pricesOptionsCaption => 'Vous pouvez annuler la facture renouvelée à tout moment. Le paiement sera effectué via votre compte Google Pay lorsque vous déciderez d\'acheter l\'abonnement. Votre abonnement sera renouvelé 24 heures avant l\'expiration de votre abonnement.';

  @override
  String get activities => 'Activities';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen Soutien';

  @override
  String get emailSupportBody => 'Bonjour! Vous pouvez écrire votre message ici';

  @override
  String get support => 'Soutien';

  @override
  String get termsofuse => 'Conditions d\'utilisation';

  @override
  String get privacypolicy => 'Politique de confidentialité';

  @override
  String get rateus => 'Évaluez nous';

  @override
  String get premiumBenefits => 'Avantages des membres Premium';

  @override
  String get generalSettings => 'réglages généraux';

  @override
  String get email => 'E-mail';

  @override
  String get premium => 'Pro';

  @override
  String get addNumber => 'Ajouter un numéro';

  @override
  String get switchPro => 'Passer en prime';

  @override
  String get procesing => 'Traitement';

  @override
  String get onHold => 'En attente';

  @override
  String get nullActivityText => 'Aucune activité enregistrée trouvée';

  @override
  String get nullActivityCaption => 'Le numéro affiché n\'a pas encore d\'activité enregistrée. Lorsque l\'activité est trouvée, les enregistrements commencent à être répertoriés.';

  @override
  String get activeTime => 'Temps actif';

  @override
  String get second => 'deux';

  @override
  String get onlineTime => 'Temps d\'activité';

  @override
  String get activeNumber => 'Numéro actif';

  @override
  String get daily => 'du quotidien';

  @override
  String get weekly => 'Hebdomadaire';

  @override
  String get successful => 'Transaction réussie';

  @override
  String get successfulAddNumberCaption => 'Votre numéro a été ajouté avec succès. Vous recevrez une notification lorsque le suivi commencera. Ce processus peut prendre du temps en fonction de la densité du système.';

  @override
  String get okay => 'D\'accord';

  @override
  String get unsuccessful => 'L\'opération a échoué';

  @override
  String get unsuccessfulCaption => 'Nous avons rencontré un problème. Veuillez réessayer plus tard.';

  @override
  String get numberSettings => 'Paramètres du numéro';

  @override
  String get namedNumber => 'Nommez le numéro';

  @override
  String get onlineNotification => 'Avis en ligne';

  @override
  String get removeNumber => 'Supprimer le numéro';

  @override
  String get removeNumberCaption => 'Attention! Lorsque vous supprimez le numéro, les activités passées sont supprimées.';

  @override
  String get newPhoneCaption => 'Pour utiliser l\'application, vous devez ajouter un numéro de téléphone Whatsapp.';

  @override
  String get startTracking => 'Démarrer le suivi';

  @override
  String get trackingPolicy => 'En continuant, vous acceptez notre politique de confidentialité et notre CLUF';

  @override
  String get filter => 'Filtre';

  @override
  String get changeLang => 'Changer de langue';
}
