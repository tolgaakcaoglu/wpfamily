import 'app_localizations.dart';

/// The translations for Russian (`ru`).
class AppLocalizationsRu extends AppLocalizations {
  AppLocalizationsRu([String locale = 'ru']) : super(locale);

  @override
  String get language => 'Русский';

  @override
  String get addPhoneNullFieldError => 'Вы должны заполнить все поля, чтобы начать отслеживание.';

  @override
  String get addPhoneLimitError => 'Срок действия вашего права на использование истек.';

  @override
  String get tryFree => 'Попробуйте бесплатно';

  @override
  String get freeTrialTitle => 'Попробуйте 8 часов премиум бесплатно 😍';

  @override
  String get freeTrialLabel1 => 'Мгновенные уведомления об активности';

  @override
  String get freeTrialLabel2 => 'Подробные отчеты о деятельности';

  @override
  String get freeTrialLabel3 => 'Неограниченный доступ ко всем функциям';

  @override
  String get freeTrialTryButton => 'Начать бесплатную пробную версию';

  @override
  String get freeTrialCaption => 'Срок действия бесплатной пробной версии истекает через 8 часов с момента ее запуска. В течение этого периода у вас будут премиум-функции, упомянутые выше. Если пакет не продлевается в конце периода, премиум-функции отключаются. Вам нужно купить пакет.';

  @override
  String get close => 'Закрывать';

  @override
  String get pricesOptionsTitle => 'Не выходите за рамки! 😊';

  @override
  String get contin => 'Продолжать';

  @override
  String get pricesOptionsCaption => 'Вы можете отменить обновленный счет в любое время. Оплата будет производиться через вашу учетную запись Google Pay, когда вы решите приобрести подписку. Ваша подписка будет продлена за 24 часа до истечения срока действия подписки.';

  @override
  String get activities => 'мероприятия';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen Поддерживать';

  @override
  String get emailSupportBody => 'Привет! Вы можете написать свое сообщение здесь';

  @override
  String get support => 'Поддерживать';

  @override
  String get termsofuse => 'Условия эксплуатации';

  @override
  String get privacypolicy => 'Политика конфиденциальности';

  @override
  String get rateus => 'Оцените нас';

  @override
  String get premiumBenefits => 'Преимущества премиум-члена';

  @override
  String get generalSettings => 'общие настройки';

  @override
  String get email => 'Эл. почта';

  @override
  String get premium => 'Про';

  @override
  String get addNumber => 'Добавить число';

  @override
  String get switchPro => 'Перейти на премиум';

  @override
  String get procesing => 'Обработка';

  @override
  String get onHold => 'На удерживании';

  @override
  String get nullActivityText => 'Записанная активность не найдена';

  @override
  String get nullActivityCaption => 'Показанный номер еще не зарегистрирован. Когда действие будет найдено, записи начнут отображаться в списке.';

  @override
  String get activeTime => 'Активное время';

  @override
  String get second => 'вто';

  @override
  String get onlineTime => 'Активное время';

  @override
  String get activeNumber => 'Активный номер';

  @override
  String get daily => 'Повседневная';

  @override
  String get weekly => 'Еженедельно';

  @override
  String get successful => 'Транзакция прошла успешно';

  @override
  String get successfulAddNumberCaption => 'Ваш номер успешно добавлен. Вы получите уведомление, когда начнется отслеживание. Этот процесс может занять некоторое время в зависимости от плотности системы.';

  @override
  String get okay => 'Хорошо';

  @override
  String get unsuccessful => 'Операция не удалась';

  @override
  String get unsuccessfulCaption => 'Мы столкнулись с проблемой. Пожалуйста, попробуйте позже.';

  @override
  String get numberSettings => 'Настройки номера';

  @override
  String get namedNumber => 'Назовите номер';

  @override
  String get onlineNotification => 'Онлайн-уведомление';

  @override
  String get removeNumber => 'Удалить номер';

  @override
  String get removeNumberCaption => 'Внимание! Когда вы удаляете номер, прошлые действия удаляются.';

  @override
  String get newPhoneCaption => 'Для того, чтобы использовать приложение, вам необходимо добавить номер телефона Whatsapp.';

  @override
  String get startTracking => 'Начать отслеживание';

  @override
  String get trackingPolicy => 'Продолжая, вы соглашаетесь с нашей Политикой конфиденциальности и EULA.';

  @override
  String get filter => 'Фильтр';

  @override
  String get changeLang => 'изменение языка';
}
