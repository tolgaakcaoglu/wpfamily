import 'app_localizations.dart';

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get language => '中文（方言';

  @override
  String get addPhoneNullFieldError => '您必须填写所有字段才能开始跟踪。';

  @override
  String get addPhoneLimitError => '您的使用权已过期。';

  @override
  String get tryFree => '免费试用';

  @override
  String get freeTrialTitle => '免费试用8小时保费😍';

  @override
  String get freeTrialLabel1 => '即时活动通知';

  @override
  String get freeTrialLabel2 => '详细的活动报告';

  @override
  String get freeTrialLabel3 => '无限制访问所有功能';

  @override
  String get freeTrialTryButton => '开始免费试用';

  @override
  String get freeTrialCaption => '您的免费试用版将在您开始试用之日起 8 小时后到期。在此期间，您将拥有上述高级功能。如果在期限结束时未续订套餐，则高级功能将被禁用。您需要购买包裹。';

  @override
  String get close => '关';

  @override
  String get pricesOptionsTitle => '不要达到极限！ 😊';

  @override
  String get contin => '继续';

  @override
  String get pricesOptionsCaption => '您可以随时取消续订的发票。当您决定购买订阅时，将通过您的 Google Pay 帐户进行付款。您的订阅将在订阅到期前 24 小时续订。';

  @override
  String get activities => '活动';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen 支持';

  @override
  String get emailSupportBody => '你好呀！你可以在这里写下你的信息';

  @override
  String get support => '支持';

  @override
  String get termsofuse => '使用条款';

  @override
  String get privacypolicy => '隐私政策';

  @override
  String get rateus => '评价我们';

  @override
  String get premiumBenefits => '高级会员福利';

  @override
  String get generalSettings => '通用设置';

  @override
  String get email => '电子邮件';

  @override
  String get premium => '临';

  @override
  String get addNumber => '加号码';

  @override
  String get switchPro => '切换到高级';

  @override
  String get procesing => '加工';

  @override
  String get onHold => '等候接听';

  @override
  String get nullActivityText => '未找到记录的活动';

  @override
  String get nullActivityCaption => '显示的号码还没有注册活动。找到活动后，将开始列出记录。';

  @override
  String get activeTime => '活动时间';

  @override
  String get second => '第二';

  @override
  String get onlineTime => '活动时间';

  @override
  String get activeNumber => '活跃号码';

  @override
  String get daily => '日常的';

  @override
  String get weekly => '每周';

  @override
  String get successful => '交易成功';

  @override
  String get successfulAddNumberCaption => '您的号码已成功添加。跟踪开始时，您将收到通知。此过程可能需要时间，具体取决于系统密度。';

  @override
  String get okay => '好的';

  @override
  String get unsuccessful => '手术失败';

  @override
  String get unsuccessfulCaption => '我们遇到了一个问题。请稍后再试。';

  @override
  String get numberSettings => '号码设置';

  @override
  String get namedNumber => '命名号码';

  @override
  String get onlineNotification => '在线通知';

  @override
  String get removeNumber => '删除号码';

  @override
  String get removeNumberCaption => '注意力！当您删除该号码时，过去的活动将被删除。';

  @override
  String get newPhoneCaption => '为了使用该应用程序，您需要添加一个 Whatsapp 电话号码。';

  @override
  String get startTracking => '开始追踪';

  @override
  String get trackingPolicy => '继续即表示您同意我们的隐私政策和 EULA';

  @override
  String get filter => '筛选';

  @override
  String get changeLang => '改变语言';
}
