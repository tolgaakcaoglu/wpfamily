import 'app_localizations.dart';

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get language => 'English';

  @override
  String get addPhoneNullFieldError => 'You must fill in all fields to start tracking.';

  @override
  String get addPhoneLimitError => 'Your right of use has expired.';

  @override
  String get tryFree => 'Try it for free';

  @override
  String get freeTrialTitle => 'Try 8 hours premium for free 😍';

  @override
  String get freeTrialLabel1 => 'Instant activity notifications';

  @override
  String get freeTrialLabel2 => 'Detailed activity reports';

  @override
  String get freeTrialLabel3 => 'Unlimited access to all features';

  @override
  String get freeTrialTryButton => 'Start Free Trial';

  @override
  String get freeTrialCaption => 'Your free trial expires 8 hours from the date you started it. During this period, you will have the premium features mentioned above. If the package is not renewed at the end of the period, the premium features are disabled. You need to buy the package.';

  @override
  String get close => 'Close';

  @override
  String get pricesOptionsTitle => 'Don\'t hit the limits! 😊';

  @override
  String get contin => 'Continue';

  @override
  String get pricesOptionsCaption => 'You can cancel the renewed invoice at any time. Payment will be made through your Google Pay account when you decide to purchase the subscription. Your subscription will be renewed 24 hours before your subscription expires.';

  @override
  String get activities => 'Activities';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen Support';

  @override
  String get emailSupportBody => 'Hello there! You can write your message here';

  @override
  String get support => 'Support';

  @override
  String get termsofuse => 'Terms of use';

  @override
  String get privacypolicy => 'Privacy Policy';

  @override
  String get rateus => 'Rate Us';

  @override
  String get premiumBenefits => 'Premium Member Benefits';

  @override
  String get generalSettings => 'General Settings';

  @override
  String get email => 'E-mail';

  @override
  String get premium => 'Premium';

  @override
  String get addNumber => 'Add Number';

  @override
  String get switchPro => 'Switch to premium';

  @override
  String get procesing => 'Processing';

  @override
  String get onHold => 'On hold';

  @override
  String get nullActivityText => 'No recorded activity found';

  @override
  String get nullActivityCaption => 'The number shown has no registered activity yet. When the activity is found, the records will start to be listed.';

  @override
  String get activeTime => 'Active time';

  @override
  String get second => 'sec';

  @override
  String get onlineTime => 'Activite Time';

  @override
  String get activeNumber => 'Active Number';

  @override
  String get daily => 'Daily';

  @override
  String get weekly => 'Weekly';

  @override
  String get successful => 'Transaction Successful';

  @override
  String get successfulAddNumberCaption => 'Your number has been successfully added. You will receive notification when tracking starts. This process may take time depending on the system density.';

  @override
  String get okay => 'Ok';

  @override
  String get unsuccessful => 'Operation Failed';

  @override
  String get unsuccessfulCaption => 'We ran into a problem. please try again later.';

  @override
  String get numberSettings => 'Number Settings';

  @override
  String get namedNumber => 'Name the Number';

  @override
  String get onlineNotification => 'Online Notification';

  @override
  String get removeNumber => 'Remove Number';

  @override
  String get removeNumberCaption => 'Attention! When you delete the number, past activities are deleted.';

  @override
  String get newPhoneCaption => 'In order to use the application, you need to add a Whatsapp phone number.';

  @override
  String get startTracking => 'Start Tracking';

  @override
  String get trackingPolicy => 'By continuing you agree to our Privacy Policy and EULA';

  @override
  String get filter => 'Filter';

  @override
  String get changeLang => 'Change language';
}
