import 'app_localizations.dart';

/// The translations for Indonesian (`id`).
class AppLocalizationsId extends AppLocalizations {
  AppLocalizationsId([String locale = 'id']) : super(locale);

  @override
  String get language => 'bahasa Indonesia';

  @override
  String get addPhoneNullFieldError => 'Anda harus mengisi semua bidang untuk memulai pelacakan.';

  @override
  String get addPhoneLimitError => 'Hak penggunaan Anda telah kedaluwarsa.';

  @override
  String get tryFree => 'Cobalah secara gratis';

  @override
  String get freeTrialTitle => 'Coba premium 8 jam gratis 😍';

  @override
  String get freeTrialLabel1 => 'Pemberitahuan aktivitas instan';

  @override
  String get freeTrialLabel2 => 'Laporan aktivitas terperinci';

  @override
  String get freeTrialLabel3 => 'Akses tak terbatas ke semua fitur';

  @override
  String get freeTrialTryButton => 'Mulai Uji Coba Gratis';

  @override
  String get freeTrialCaption => 'Uji coba gratis Anda berakhir 8 jam sejak tanggal Anda memulainya. Selama periode ini, Anda akan memiliki fitur premium yang disebutkan di atas. Jika paket tidak diperpanjang pada akhir periode, fitur premium dinonaktifkan. Anda perlu membeli paket.';

  @override
  String get close => 'Menutup';

  @override
  String get pricesOptionsTitle => 'Jangan mencapai batas! 😊';

  @override
  String get contin => 'Melanjutkan';

  @override
  String get pricesOptionsCaption => 'Anda dapat membatalkan faktur yang diperbarui kapan saja. Pembayaran akan dilakukan melalui akun Google Pay Anda saat Anda memutuskan untuk membeli langganan. Langganan Anda akan diperpanjang 24 jam sebelum langganan Anda berakhir.';

  @override
  String get activities => 'Kegiatan';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen Mendukung';

  @override
  String get emailSupportBody => 'Halo! Anda dapat menulis pesan Anda di sini';

  @override
  String get support => 'Mendukung';

  @override
  String get termsofuse => 'Syarat Penggunaan';

  @override
  String get privacypolicy => 'Kebijakan pribadi';

  @override
  String get rateus => 'Nilai Kami';

  @override
  String get premiumBenefits => 'Manfaat Anggota Premium';

  @override
  String get generalSettings => 'Pengaturan Umum';

  @override
  String get email => 'Surel';

  @override
  String get premium => 'Pro';

  @override
  String get addNumber => 'Tambahkan nomor';

  @override
  String get switchPro => 'Beralih ke premium';

  @override
  String get procesing => 'Pengolahan';

  @override
  String get onHold => 'Tertahan';

  @override
  String get nullActivityText => 'Tidak ditemukan aktivitas yang direkam';

  @override
  String get nullActivityCaption => 'Nomor yang ditampilkan belum memiliki aktivitas terdaftar. Ketika aktivitas ditemukan, catatan akan mulai terdaftar.';

  @override
  String get activeTime => 'Waktu aktif';

  @override
  String get second => 'ked';

  @override
  String get onlineTime => 'Waktu Aktif';

  @override
  String get activeNumber => 'Nomor Aktif';

  @override
  String get daily => 'Harian';

  @override
  String get weekly => 'Mingguan';

  @override
  String get successful => 'Transaksi Berhasil';

  @override
  String get successfulAddNumberCaption => 'Nomor Anda telah berhasil ditambahkan. Anda akan menerima pemberitahuan saat pelacakan dimulai. Proses ini mungkin memakan waktu tergantung pada kepadatan sistem.';

  @override
  String get okay => 'Oke';

  @override
  String get unsuccessful => 'Operasi gagal';

  @override
  String get unsuccessfulCaption => 'Kami mengalami masalah. silakan coba lagi nanti.';

  @override
  String get numberSettings => 'Pengaturan Nomor';

  @override
  String get namedNumber => 'Sebutkan Nomornya';

  @override
  String get onlineNotification => 'Pemberitahuan Online';

  @override
  String get removeNumber => 'Hapus Nomor';

  @override
  String get removeNumberCaption => 'Perhatian! Saat Anda menghapus nomornya, aktivitas sebelumnya akan dihapus.';

  @override
  String get newPhoneCaption => 'Untuk menggunakan aplikasi ini, Anda perlu menambahkan nomor telepon Whatsapp.';

  @override
  String get startTracking => 'Mulai Pelacakan';

  @override
  String get trackingPolicy => 'Dengan melanjutkan, Anda menyetujui Kebijakan Privasi dan EULA kami';

  @override
  String get filter => 'Saring';

  @override
  String get changeLang => 'Ganti bahasa';
}
