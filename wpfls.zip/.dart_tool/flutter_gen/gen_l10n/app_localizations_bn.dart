import 'app_localizations.dart';

/// The translations for Bengali Bangla (`bn`).
class AppLocalizationsBn extends AppLocalizations {
  AppLocalizationsBn([String locale = 'bn']) : super(locale);

  @override
  String get language => 'বাংলা';

  @override
  String get addPhoneNullFieldError => 'ট্র্যাকিং শুরু করতে আপনাকে অবশ্যই সমস্ত ক্ষেত্র পূরণ করতে হবে।';

  @override
  String get addPhoneLimitError => 'আপনার ব্যবহারের অধিকারের মেয়াদ শেষ হয়ে গেছে।';

  @override
  String get tryFree => 'বিনামূল্যে এটি চেষ্টা করুন';

  @override
  String get freeTrialTitle => 'বিনামূল্যে 8 ঘন্টা প্রিমিয়াম চেষ্টা করুন 😍';

  @override
  String get freeTrialLabel1 => 'তাত্ক্ষণিক কার্যকলাপ বিজ্ঞপ্তি';

  @override
  String get freeTrialLabel2 => 'বিস্তারিত কার্যকলাপ রিপোর্ট';

  @override
  String get freeTrialLabel3 => 'সমস্ত বৈশিষ্ট্য সীমাহীন অ্যাক্সেস';

  @override
  String get freeTrialTryButton => 'বিনামূল্যে ট্রায়াল শুরু করুন';

  @override
  String get freeTrialCaption => 'আপনার বিনামূল্যে ট্রায়াল আপনি এটি শুরু করার তারিখ থেকে 8 ঘন্টা মেয়াদ শেষ হবে. এই সময়ের মধ্যে, আপনার উপরে উল্লিখিত প্রিমিয়াম বৈশিষ্ট্যগুলি থাকবে৷ মেয়াদ শেষে প্যাকেজ পুনর্নবীকরণ করা না হলে, প্রিমিয়াম বৈশিষ্ট্য অক্ষম করা হয়। আপনাকে প্যাকেজ কিনতে হবে।';

  @override
  String get close => 'বন্ধ';

  @override
  String get pricesOptionsTitle => 'সীমা আঘাত করবেন না! 😊';

  @override
  String get contin => 'চালিয়ে যান';

  @override
  String get pricesOptionsCaption => 'আপনি যে কোনো সময় পুনর্নবীকরণ করা চালান বাতিল করতে পারেন। আপনি যখন সদস্যতা কেনার সিদ্ধান্ত নেবেন তখন আপনার Google Pay অ্যাকাউন্টের মাধ্যমে অর্থপ্রদান করা হবে। আপনার সদস্যতার মেয়াদ শেষ হওয়ার 24 ঘন্টা আগে আপনার সদস্যতা পুনর্নবীকরণ করা হবে।';

  @override
  String get activities => 'কার্যক্রম';

  @override
  String get emailSupportSubject => 'Wp Family Last Seen সমর্থন';

  @override
  String get emailSupportBody => 'হ্যালো সেখানে! আপনি এখানে আপনার বার্তা লিখতে পারেন';

  @override
  String get support => 'সমর্থন';

  @override
  String get termsofuse => 'ব্যবহারের শর্তাবলী';

  @override
  String get privacypolicy => 'গোপনীয়তা নীতি';

  @override
  String get rateus => 'আমাদের ব্যাপারে আপনার মতামত দিন';

  @override
  String get premiumBenefits => 'প্রিমিয়াম সদস্য সুবিধা';

  @override
  String get generalSettings => 'সাধারণ সেটিংস';

  @override
  String get email => 'ই-মেইল';

  @override
  String get premium => 'প্রো';

  @override
  String get addNumber => 'সংখা যোগ কর';

  @override
  String get switchPro => 'প্রিমিয়ামে স্যুইচ করুন';

  @override
  String get procesing => 'প্রক্রিয়াকরণ';

  @override
  String get onHold => 'স্হগিত';

  @override
  String get nullActivityText => 'কোন রেকর্ড করা কার্যকলাপ পাওয়া যায়নি';

  @override
  String get nullActivityCaption => 'দেখানো সংখ্যাটি এখনও কোনো নিবন্ধিত কার্যকলাপ নেই. কার্যকলাপ পাওয়া গেলে, রেকর্ড তালিকাভুক্ত করা শুরু হবে.';

  @override
  String get activeTime => 'সক্রিয় সময়';

  @override
  String get second => 'দ্বিতীয়';

  @override
  String get onlineTime => 'সক্রিয় সময়';

  @override
  String get activeNumber => 'সক্রিয় নম্বর';

  @override
  String get daily => 'দৈনিক';

  @override
  String get weekly => 'সাপ্তাহিক';

  @override
  String get successful => 'সফল লেনদেন';

  @override
  String get successfulAddNumberCaption => 'আপনার নম্বর সফলভাবে যোগ করা হয়েছে. ট্র্যাকিং শুরু হলে আপনি বিজ্ঞপ্তি পাবেন। এই প্রক্রিয়াটি সিস্টেমের ঘনত্বের উপর নির্ভর করে সময় নিতে পারে।';

  @override
  String get okay => 'ঠিক আছে';

  @override
  String get unsuccessful => 'অপারেশন ব্যর্থ হয়েছে';

  @override
  String get unsuccessfulCaption => 'আমরা একটি সমস্যায় পড়েছিলাম। অনুগ্রহ করে একটু পরে আবার চেষ্টা করুন.';

  @override
  String get numberSettings => 'নম্বর সেটিংস';

  @override
  String get namedNumber => 'নম্বরের নাম দিন';

  @override
  String get onlineNotification => 'অনলাইন বিজ্ঞপ্তি';

  @override
  String get removeNumber => 'নম্বর সরান';

  @override
  String get removeNumberCaption => 'মনোযোগ! আপনি নম্বর মুছে ফেললে, অতীতের কার্যকলাপ মুছে ফেলা হয়।';

  @override
  String get newPhoneCaption => 'অ্যাপ্লিকেশনটি ব্যবহার করার জন্য, আপনাকে একটি Whatsapp ফোন নম্বর যোগ করতে হবে।';

  @override
  String get startTracking => 'ট্র্যাকিং শুরু করুন';

  @override
  String get trackingPolicy => 'চালিয়ে যাওয়ার মাধ্যমে আপনি আমাদের গোপনীয়তা নীতি এবং EULA তে সম্মত হন';

  @override
  String get filter => 'ছাঁকনি';

  @override
  String get changeLang => 'ভাষা পরিবর্তন করুন';
}
