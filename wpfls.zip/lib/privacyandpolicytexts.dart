String privacyText = 'privacy';
String policyText = 'policy';
